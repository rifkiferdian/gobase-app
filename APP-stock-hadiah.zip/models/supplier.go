package models

type Supplier struct {
	SupplierID   int
	SupplierName string
	Active       int
	Description  string
	CreatedAt    string
}
