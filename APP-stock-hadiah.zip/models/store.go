package models

// Store merepresentasikan data toko.
type Store struct {
	StoreID   int
	StoreName string
}
